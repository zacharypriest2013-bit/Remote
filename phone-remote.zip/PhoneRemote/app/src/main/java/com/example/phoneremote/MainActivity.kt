package com.example.phoneremote

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.SecureRandom
import java.util.Collections

class MainActivity : Activity() {
    private val REQ = 1
    private val rnd = SecureRandom()
    private val chars = "abcdefghjkmnpqrstuvwxyz23456789"
    private lateinit var pw: String
    private lateinit var peerId: String
    private lateinit var status: TextView

    private fun rand(n: Int) = (1..n).map { chars[rnd.nextInt(chars.length)] }.joinToString("")

    private fun loadCreds(reset: Boolean) {
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        if (reset || !prefs.contains("pw")) {
            prefs.edit().putString("pw", rand(10)).putString("id", "pr" + rand(12)).apply()
        }
        pw = prefs.getString("pw", "")!!
        peerId = prefs.getString("id", "")!!
    }

    private fun creds() = "Phone ID: $peerId\nPassword: $pw"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 0)
        }
        loadCreds(false)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { f() }
        }
        status = TextView(this).apply { textSize = 17f; setPadding(0, 48, 0, 0); setTextIsSelectable(true) }
        status.text = "Step 1: enable tap control.\nStep 2: start sharing.\n\n" + creds()
        layout.addView(btn("1. Enable tap control (Accessibility)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        layout.addView(btn("2. Start sharing") {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
        })
        layout.addView(btn("Stop sharing") {
            stopService(Intent(this, CaptureService::class.java))
            status.text = "Stopped.\n\n" + creds()
        })
        layout.addView(btn("New ID + password") {
            stopService(Intent(this, CaptureService::class.java))
            loadCreds(true)
            status.text = "New login created.\n\n" + creds()
        })
        layout.addView(status)
        setContentView(layout)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
                .putExtra("pin", pw)
                .putExtra("id", peerId)
            startForegroundService(i)
            status.text = "Sharing!\n\nFrom anywhere: open your controller page and enter\n" + creds() +
                "\n\nSame Wi-Fi only: http://${localIp()}:8080 (password above)"
        }
    }

    private fun localIp(): String {
        try {
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (a in Collections.list(ni.inetAddresses)) {
                    if (!a.isLoopbackAddress && a is Inet4Address && a.isSiteLocalAddress) {
                        return a.hostAddress ?: ""
                    }
                }
            }
        } catch (e: Exception) { }
        return "PHONE-IP"
    }
}
