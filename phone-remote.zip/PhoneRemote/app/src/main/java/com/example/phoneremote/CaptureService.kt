package com.example.phoneremote

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.concurrent.atomic.AtomicBoolean
import android.util.DisplayMetrics
import android.view.WindowManager
import fi.iki.elonen.NanoHTTPD
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var server: RemoteServer? = null
    private var thread: HandlerThread? = null
    @Volatile private var latest: ByteArray? = null
    private var lastEncode = 0L
    private var fullBmp: Bitmap? = null
    private var dirty = false
    private var encodeScheduled = false
    private val keepAlive = object : Runnable {
        override fun run() {
            pushFrame(latest)
            main.postDelayed(this, 1500)
        }
    }
    private var webView: WebView? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var controller = false
    private val sending = AtomicBoolean(false)

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        cleanup()

        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("remote", "Phone Remote", NotificationManager.IMPORTANCE_LOW)
        )
        val notif = notif("Starting...")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notif)
        }

        val code = intent.getIntExtra("code", 0)
        val data = intent.getParcelableExtra<Intent>("data")!!
        val pin = intent.getStringExtra("pin") ?: "0000"
        val peerId = intent.getStringExtra("id") ?: "pr0"

        thread = HandlerThread("capture").also { it.start() }
        val handler = Handler(thread!!.looper)

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        val dm = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val scale = minOf(1f, 720f / dm.widthPixels)
        val w = (dm.widthPixels * scale).toInt()
        val h = (dm.heightPixels * scale).toInt()

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val p = img.planes[0]
                val rowPad = p.rowStride - p.pixelStride * w
                if (fullBmp == null) {
                    fullBmp = Bitmap.createBitmap(w + rowPad / p.pixelStride, h, Bitmap.Config.ARGB_8888)
                }
                fullBmp!!.copyPixelsFromBuffer(p.buffer)
                dirty = true
            } finally {
                img.close()
            }
            // Always encode the newest frame, just not more than ~10 times a second.
            if (!encodeScheduled) {
                encodeScheduled = true
                val wait = maxOf(0L, 100L - (System.currentTimeMillis() - lastEncode))
                handler.postDelayed({
                    encodeScheduled = false
                    if (dirty) { dirty = false; encodeFrame(w, h) }
                }, wait)
            }
        }, handler)

        display = projection!!.createVirtualDisplay(
            "remote", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )

        server = RemoteServer(this, pin) { latest }
        server!!.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
        startWebView(peerId, pin)
        main.postDelayed(keepAlive, 1500)
        return START_NOT_STICKY
    }

    private fun notif(text: String): Notification = Notification.Builder(this, "remote")
        .setContentTitle("Phone Remote is sharing your screen")
        .setContentText(text)
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .build()

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    private fun startWebView(id: String, pw: String) {
        val wv = WebView(applicationContext)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.mediaPlaybackRequiresUserGesture = false
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript("start('$id','$pw')", null)
            }
        }
        val html = assets.open("phone.html").bufferedReader().use { it.readText() }
        wv.loadDataWithBaseURL("https://localhost/", html, "text/html", "utf-8", null)
        wv.onResume()
        wv.resumeTimers()
        webView = wv
    }

    private fun pushFrame(bytes: ByteArray?) {
        if (bytes == null || !controller) return
        if (!sending.compareAndSet(false, true)) return
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        main.post {
            val wv = webView
            if (wv == null) sending.set(false)
            else wv.evaluateJavascript("onFrame('$b64')") { sending.set(false) }
        }
    }

    inner class Bridge {
        @JavascriptInterface fun status(s: String) {
            controller = s.startsWith("controller")
            main.post {
                (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, notif(s))
            }
            if (controller) pushFrame(latest)
        }
        @JavascriptInterface fun tap(x: Double, y: Double) {
            main.post { RemoteAccessibilityService.instance?.tap(x.toFloat(), y.toFloat()) }
        }
        @JavascriptInterface fun swipe(x1: Double, y1: Double, x2: Double, y2: Double, ms: Double) {
            main.post {
                RemoteAccessibilityService.instance?.swipe(
                    x1.toFloat(), y1.toFloat(), x2.toFloat(), y2.toFloat(), ms.toLong()
                )
            }
        }
        @JavascriptInterface fun key(k: String) {
            main.post { RemoteAccessibilityService.instance?.key(k) }
        }
    }

    private fun encodeFrame(w: Int, h: Int) {
        try {
            val full = fullBmp ?: return
            val crop = Bitmap.createBitmap(full, 0, 0, w, h)
            val out = ByteArrayOutputStream()
            crop.compress(Bitmap.CompressFormat.JPEG, 55, out)
            crop.recycle()
            val bytes = out.toByteArray()
            lastEncode = System.currentTimeMillis()
            latest = bytes
            pushFrame(bytes)
        } catch (e: Exception) { }
    }

    private fun cleanup() {
        try { server?.stop() } catch (e: Exception) { }
        try { display?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        controller = false
        main.removeCallbacks(keepAlive)
        fullBmp = null; dirty = false; encodeScheduled = false; latest = null
        try { webView?.destroy() } catch (e: Exception) { }
        webView = null
        thread?.quitSafely()
        server = null; display = null; reader = null; projection = null; thread = null
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }
}

class RemoteServer(
    private val ctx: Context,
    private val pin: String,
    private val frame: () -> ByteArray?
) : NanoHTTPD(8080) {

    override fun serve(s: IHTTPSession): Response {
        if (s.uri == "/") {
            val html = ctx.assets.open("index.html").bufferedReader().use { it.readText() }
            return newFixedLengthResponse(Response.Status.OK, "text/html", html)
        }
        val p = s.parms
        if (p["pin"] != pin) {
            return newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain", "wrong pin")
        }
        fun f(k: String) = p[k]?.toFloatOrNull() ?: 0f
        val svc = RemoteAccessibilityService.instance
        return when (s.uri) {
            "/frame.jpg" -> {
                val b = frame() ?: return newFixedLengthResponse(
                    Response.Status.NOT_FOUND, "text/plain", "no frame yet"
                )
                newFixedLengthResponse(
                    Response.Status.OK, "image/jpeg", ByteArrayInputStream(b), b.size.toLong()
                ).also { it.addHeader("Cache-Control", "no-store") }
            }
            "/tap" -> { svc?.tap(f("x"), f("y")); ok(svc != null) }
            "/swipe" -> {
                svc?.swipe(f("x1"), f("y1"), f("x2"), f("y2"), (p["ms"]?.toLongOrNull() ?: 200L))
                ok(svc != null)
            }
            "/key" -> { svc?.key(p["k"] ?: ""); ok(svc != null) }
            else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "not found")
        }
    }

    private fun ok(hasAccess: Boolean) = newFixedLengthResponse(
        Response.Status.OK, "text/plain", if (hasAccess) "ok" else "tap control not enabled"
    )
}
